# :octocat:Dashboard👇
![Screenshot 2023-07-28 152259](https://github.com/yashdoshi12/Sales_report_using_PowerBi/assets/39629707/23e117f3-fd1d-4c0b-a0a7-391795d3ca79)

<hr />
<br />

# <div align="center">Don't forget to leave a star ⭐️</div>
